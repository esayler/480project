ace.define("ace/snippets/julia",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="julia"})
;
