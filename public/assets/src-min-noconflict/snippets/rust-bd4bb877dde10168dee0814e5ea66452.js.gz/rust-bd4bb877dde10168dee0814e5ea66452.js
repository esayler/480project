ace.define("ace/snippets/rust",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="rust"})
;
