ace.define("ace/snippets/glsl",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="glsl"})
;
