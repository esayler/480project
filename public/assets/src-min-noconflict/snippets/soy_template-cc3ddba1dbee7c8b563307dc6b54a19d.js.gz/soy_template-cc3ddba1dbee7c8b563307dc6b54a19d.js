ace.define("ace/snippets/soy_template",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="soy_template"})
;
