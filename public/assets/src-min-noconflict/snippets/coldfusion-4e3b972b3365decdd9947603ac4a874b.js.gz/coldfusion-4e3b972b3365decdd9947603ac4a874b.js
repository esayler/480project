ace.define("ace/snippets/coldfusion",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="coldfusion"})
;
