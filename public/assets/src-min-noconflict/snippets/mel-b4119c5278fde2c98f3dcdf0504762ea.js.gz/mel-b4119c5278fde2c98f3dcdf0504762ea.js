ace.define("ace/snippets/mel",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="mel"})
;
